using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace WindowsGame1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        KeyboardState states;
        Texture2D fon1;
        Sprites hero;
        
        static int screenWidth=1200;
        static int screenHeigh = 650;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = screenWidth; //������ ������ 
            graphics.PreferredBackBufferHeight = screenHeigh; //��� ������   
            graphics.IsFullScreen = false; //�������� ������������� �����

            hero = new Sprites(12);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
      //      hero.rect = new Rectangle(30, screenHeigh-70, 35, 50);
            hero.heroPlacement = new Rectangle(30, screenHeigh-70, 64, 64);
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            
            fon1 = Content.Load<Texture2D>("fon1");
            hero.LoadContent(Content, "SPRITESANIMHERO");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            states = Keyboard.GetState();//������������� ������� keys. 

            if (states.IsKeyDown(Keys.Escape))    //���������, ������ �� ������� 
            {
                this.Exit();//���� ������� ������, �� ���������� �����
            }
            if (states.IsKeyDown(Keys.Right))
            {
                hero.Update(gameTime, 2);
            }
            else if (states.IsKeyDown(Keys.Left))
            {
                hero.Update(gameTime, 1);
            }
            else
            {
                hero.Update(gameTime, 0);
            }
            if (states.IsKeyDown(Keys.Space))
            {
                hero.Update(gameTime, 3);
            }
            
            
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin(); //�������� ���������� (���������) ����������� �� ������. 

            spriteBatch.Draw(fon1, new Vector2(0, 0), Color.White);

            if (states.IsKeyDown(Keys.Right))
            {
                hero.DrawAnimation(spriteBatch);
                if (! (hero.heroPlacement.Right > screenWidth-2))
                {
                    hero.heroPlacement.Offset(2, 0);
                }

            }
            else if (states.IsKeyDown(Keys.Left))
            {
                hero.DrawAnimation(spriteBatch);
                if (! (hero.heroPlacement.Left < 2))
                {
                    hero.heroPlacement.Offset(-2, 0);
                }
            }
            else if (states.IsKeyDown(Keys.Space))
            {
                hero.DrawAnimation(spriteBatch);
            }
            else
            {
                hero.DrawAnimation(spriteBatch);
            } 
                

            spriteBatch.End();//����������� ���������� (���������) ����������� �� ������. 

            base.Draw(gameTime);
        }
    }
}
