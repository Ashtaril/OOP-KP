﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace WindowsGame1
{
    class Sprites
    {
        public Texture2D spriteTexture;
        public Rectangle heroPlacement; //положение героя
        int FrameRunCount; //Количество всех фреймов в изображении (у нас это 9) 
        int frame;//какой фрейм нарисован в данный момент 
        int jmpFrame;
        float TimeForFrame;//Сколько времени нужно показывать один фрейм (скорость) 
        float TotalTime;//сколько времени прошло с показа предыдущего фрейма 
        float JumpTime; //время прыжка
        float TotalJumpTime;
        int delaycount;
        Boolean orientLeft; //куда повернут герой
        Boolean isFlying;
        Boolean isMoving;
        int lockJmp;

        public Sprites() 
        {

        }
        public Sprites(int speedAnimation) //перегрузили конструктор
        {
            frame = 0;
            TimeForFrame = (float)1 / speedAnimation;
            TotalTime = 0;
            TotalJumpTime = 0;
            FrameRunCount = 9; //пока что просто константный
            orientLeft = false;
            isFlying = false;
            isMoving = false;
            JumpTime = (float)4 / speedAnimation;
            lockJmp = 0;
        } 

        public void LoadContent(ContentManager Content, String texture)
        {
            spriteTexture = Content.Load<Texture2D>(texture);
        }

        public void Update(GameTime gameTime, int Move)
        {
            if (Move==0)
            {
                frame = 0;
                isMoving = false;
            }
            else if (Move == 1)
            {
                orientLeft = true;
                isMoving = true;
                if (!isFlying)
                {
                    TotalTime += (float)gameTime.ElapsedGameTime.TotalSeconds; // время, за которое полностью выполняется метод Update
                    if (TotalTime > TimeForFrame)
                    {
                        frame++;
                        frame = frame % (FrameRunCount - 1);
                        TotalTime -= TimeForFrame;
                    }
                }
            }
            else if (Move == 2)
            {
                isMoving = true;
                orientLeft = false;
                if (!isFlying)
                {
                    TotalTime += (float)gameTime.ElapsedGameTime.TotalSeconds; // время, за которое полностью выполняется метод Update
                    if (TotalTime > TimeForFrame)
                    {
                        frame++;
                        frame = frame % (FrameRunCount - 1);
                        TotalTime -= TimeForFrame;
                    }
                }
                
            }
            else if (Move == 3) //для прыжка свое обновление
            {
                if (lockJmp == 0) //запрет прыгать во время прыжка
                {
                    lockJmp = 1;
                    delaycount = 13;
                }
            }

            if (lockJmp == 1)
            {
                isFlying = true;
                if (TotalJumpTime > JumpTime)
                {
                    jmpFrame = 4;
                    if (delaycount > 0)
                    {
                        delaycount--;
                    }
                    else
                    {
                        lockJmp = 2;
                    }
                    return;
                }
                jmpFrame = 2;
                TotalJumpTime += (float)gameTime.ElapsedGameTime.TotalSeconds;
                heroPlacement.Offset(0, -3);
            }
            else if (lockJmp == 2)
            {
                jmpFrame = 4;
                TotalJumpTime -= (float)gameTime.ElapsedGameTime.TotalSeconds;
                heroPlacement.Offset(0, 3);
                if (TotalJumpTime <= 0)
                {
                    lockJmp = 0;
                    isFlying = false;
                }
            }

        } 

        public void Draw(SpriteBatch spriteBatch) 
        {
            spriteBatch.Draw(spriteTexture, heroPlacement, Color.White); 
        }

        public void DrawAnimation(SpriteBatch spriteBatch)
        {
            int frameWidth = spriteTexture.Width / FrameRunCount;
            Rectangle rectanglеRun = new Rectangle(frameWidth * frame, 0, frameWidth, frameWidth);
            Rectangle rectanglеJump = new Rectangle(frameWidth * jmpFrame, 64, frameWidth, frameWidth);

            if (isMoving && orientLeft && !isFlying)
            {
                SpriteEffects effect = new SpriteEffects();
                effect = SpriteEffects.FlipHorizontally;
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеRun, Color.White, 0, Vector2.Zero, effect, 0);
                #region
                        //первый параметр это текстура, второй – позиция, третий – прямоугольник для анимации, 
                        //четвертый – цвет (т.к. нам нужен прозрачный цвет закрашивания, установим Color.White). 
                        //Пятый – это поворот, но он нам не нужен, поэтому установим его в ноль. 
                        //Шестой – угол поворота. Так как поворот равен нулю, установим и угол в Vector2.Zero. 
                        //Далее идет наш эффект, а последний - это слой. Он нам тоже не нужен, установим его в ноль. 
                        #endregion  //параметры нового Draw
            }
            else if (isMoving && !orientLeft && !isFlying)
            {
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеRun, Color.White);
            }
            else if (!isMoving && orientLeft && !isFlying)
            {
                SpriteEffects effect = new SpriteEffects();
                effect = SpriteEffects.FlipHorizontally;
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеRun, Color.White, 0, Vector2.Zero, effect, 0);
            }
            else if (!isMoving && !orientLeft && !isFlying)
            {
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеRun, Color.White);
            }
            else if (isFlying && orientLeft)
            {
                SpriteEffects effect = new SpriteEffects();
                effect = SpriteEffects.FlipHorizontally;
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеJump, Color.White, 0, Vector2.Zero, effect, 0);
            }
            else if (isFlying && !orientLeft)
            {
                spriteBatch.Draw(spriteTexture, heroPlacement, rectanglеJump, Color.White);
            }
     
        } 
    }
}
